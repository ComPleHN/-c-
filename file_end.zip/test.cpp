#include<stdio.h>
#include<string.h>

void swap(STU &a,STU &b)
{
	STU tmp = a;
	a = b;
	b = tmp;
}






int main()
{
	swap(s[j],s[j+1]); 
} 
