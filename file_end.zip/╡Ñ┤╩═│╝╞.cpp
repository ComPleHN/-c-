#include<stdio.h>
#include<string.h>
/*
	����Ŀ�Ƕ����ַ���������һЩ
	��ȡʹ��
	stricmp
	strcmp
	strcpy
	strlen
*/
int main()
{
	char arr[101][20];
	char word[10];
	int  num=0;
	
	int sum = 0;
	char tmp; 
	do{
		scanf("%s",&arr[num++]);
		tmp = getchar();	
	}while(tmp != '\0' && tmp != '\n');	
	
	scanf("%s",&word);
	
	for(int i=0;i<num;i++) {
		if(!stricmp(word,arr[i])) {
			sum++;
		}
	}
	
	printf("%s %d",word,sum);
} 
